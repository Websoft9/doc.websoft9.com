## 0.0.9 release on 2023-12-14
1. zentao,magento,wordpress version format update to contentful

## 1.0.0-rc2 release on 2023-10-26
1. media init

## 1.0.0-rc1 release on 2023-10-26
1. media init